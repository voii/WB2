<?php
/**
 *

*/

/* -------------------------------------------------------- */
// Must include code to stop this file being accessed directly
if (!\defined('SYSTEM_RUN')) {\header($_SERVER['SERVER_PROTOCOL'].' 404 Not Found'); echo '404 Not Found'; \flush(); exit; }
/* -------------------------------------------------------- */

$module_directory   = 'extra_module33';
$module_name        = 'Extra module 33';
$module_function    = 'page';
$module_version     = '2.0.0';
$module_platform    = '2.13.0';
$module_author      = 'C081';
$module_license     = 'GNU General Public License';
$module_description = 'Test module';

